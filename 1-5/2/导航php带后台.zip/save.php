<?php
header('Content-Type: application/json');

$newConfig = json_decode(file_get_contents('php://input'), true);

if (json_last_error() === JSON_ERROR_NONE) {
    $result = file_put_contents('config.json', json_encode($newConfig, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    if ($result !== false) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to write to file']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid JSON']);
}