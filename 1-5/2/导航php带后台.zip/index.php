<?php
$config = json_decode(file_get_contents('config.json'), true);
$config_json = json_encode($config, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>

<!DOCTYPE html>
<html lang="en" class="vision-ui">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Haru导航</title>
    <style>
        :root {
            --color-primary: #ee75d2;
            --color-secondary: #75d8ee;
            --color-tertiary: #deee75;
            --color-quaternary: #9375ee;
            --color-surface: black;
            --bg: linear-gradient(
                to bottom,
                color-mix(in srgb, var(--color-quaternary), black 70%),
                var(--color-surface)
            );
            --color-on-surface: var(--color-primary);
            --icon-filter: saturate(3.4) brightness(0.5) invert(1);
            --ripple-filter: blur(1rem);
            --hover-filter: brightness(1.2);
            --hexagon-size: 8vmin;
            --gap: 0.1vmin;
        }

        .vision-ui {
            --color-surface-container: rgba(255, 255, 255, 0.35);
            --color-on-surface: white;
            --icon-filter: saturate(0.4);
            --ripple-filter: filter(0.2rem);
            --hover-filter: brightness(1.5);
        }

        body {
            width: 100vw;
            height: 100vh;
            display: grid;
            place-items: center;
            background: var(--bg);
            color: var(--color-on-surface);
            overflow: hidden;
            margin: 0;
            font-family: Arial, sans-serif;
        }

        body::before {
            content: "";
            position: absolute;
            inset: 0;
            pointer-events: none;
            background: radial-gradient(at center, transparent 80%, black), 
                        linear-gradient(to top, rgba(0, 0, 0, 0.3) 70%, transparent),
                        url(https://assets.codepen.io/907471/vision-pro-palm.jpg) no-repeat 45% center / cover;
            opacity: 1;
            filter: blur(0);
            transition: opacity 0.6s ease-in-out, filter 0.6s ease-in-out;
        }

        :root:not(.vision-ui) body::before {
            opacity: 0;
            filter: blur(0.5rem);
        }

        .container {
            display: flex;
            position: relative;
            align-items: center;
        }

        .column {
            margin: 0 -0.2vmin;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .hexagon {
            width: var(--hexagon-size);
            aspect-ratio: 1;
            position: relative;
            background: var(--color-surface-container, color-mix(in srgb, var(--color-secondary), var(--color-primary) var(--mix-percentage)));
            backdrop-filter: blur(1rem);
            cursor: pointer;
            clip-path: polygon(
                98.66024% 45%, 99.39693% 46.5798%, 99.84808% 48.26352%, 100% 50%,
                99.84808% 51.73648%, 99.39693% 53.4202%, 98.66025% 55%,
                78.66025% 89.64102%, 77.66044% 91.06889%, 76.42788% 92.30146%,
                75% 93.30127%, 73.4202% 94.03794%, 71.73648% 94.48909%,
                70% 94.64102%, 30% 94.64102%, 28.26352% 94.48909%,
                26.5798% 94.03794%, 25% 93.30127%, 23.57212% 92.30146%,
                22.33956% 91.06889%, 21.33975% 89.64102%, 1.33975% 55%,
                0.60307% 53.4202%, 0.15192% 51.73648%, 0% 50%,
                0.15192% 48.26352%, 0.60307% 46.5798%, 1.33975% 45%,
                21.33975% 10.35898%, 22.33956% 8.93111%, 23.57212% 7.69854%,
                25% 6.69873%, 26.5798% 5.96206%, 28.26352% 5.51091%,
                30% 5.35898%, 70% 5.35898%, 71.73648% 5.51091%,
                73.4202% 5.96206%, 75% 6.69873%, 76.42788% 7.69854%,
                77.66044% 8.93111%, 78.66025% 10.35898%
            );
            display: flex;
            justify-content: center;
            align-items: center;
            text-decoration: none;
            color: inherit;
        }

        .hexagon:hover {
            filter: var(--hover-filter);
        }

        .hexagon::before {
            content: attr(data-icon);
            font-size: 2.5vmin;
            filter: var(--icon-filter);
        }

        .hexagon::after {
            content: attr(title);
            position: absolute;
            bottom: -3vmin;
            left: 50%;
            transform: translateX(-50%);
            background: var(--color-surface-container);
            color: var(--color-on-surface);
            padding: 0.5vmin 1vmin;
            border-radius: 0.5vmin;
            font-size: 1.5vmin;
            opacity: 0;
            transition: opacity 0.3s ease;
            pointer-events: none;
            white-space: nowrap;
        }

        .hexagon:hover::after {
            opacity: 1;
        }

        #switch {
            position: absolute;
            top: 4vmin;
            right: 4vmin;
            width: 8vmin;
            height: 4vmin;
            cursor: pointer;
            background: var(--color-surface-container, color-mix(in srgb, var(--color-secondary), var(--color-primary) 12%));
            clip-path: polygon(
                98.66024% 45%, 99.39693% 46.5798%, 99.84808% 48.26352%, 100% 50%,
                99.84808% 51.73648%, 99.39693% 53.4202%, 98.66025% 55%,
                78.66025% 89.64102%, 77.66044% 91.06889%, 76.42788% 92.30146%,
                75% 93.30127%, 73.4202% 94.03794%, 71.73648% 94.48909%,
                70% 94.64102%, 30% 94.64102%, 28.26352% 94.48909%,
                26.5798% 94.03794%, 25% 93.30127%, 23.57212% 92.30146%,
                22.33956% 91.06889%, 21.33975% 89.64102%, 1.33975% 55%,
                0.60307% 53.4202%, 0.15192% 51.73648%, 0% 50%,
                0.15192% 48.26352%, 0.60307% 46.5798%, 1.33975% 45%,
                21.33975% 10.35898%, 22.33956% 8.93111%, 23.57212% 7.69854%,
                25% 6.69873%, 26.5798% 5.96206%, 28.26352% 5.51091%,
                30% 5.35898%, 70% 5.35898%, 71.73648% 5.51091%,
                73.4202% 5.96206%, 75% 6.69873%, 76.42788% 7.69854%,
                77.66044% 8.93111%, 78.66025% 10.35898%
            );
        }

        #switch::after {
            content: "🕶️";
            display: grid;
            place-items: center;
            position: absolute;
            left: 0;
            top: 0;
            height: 4vmin;
            width: 6vmin;
            transition: transform 0.3s ease;
            background: var(--color-surface-container, color-mix(in srgb, var(--color-secondary), var(--color-primary) 24%));
            clip-path: inherit;
        }

        #switch.checked::after {
            transform: translateX(2vmin);
            content: "👾";
        }

        #configModal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }

        .modal-content {
            background-color: #fefefe;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 600px;
        }

        #configTextarea {
            width: 100%;
            height: 300px;
        }

        @keyframes ripple {
            from { transform: scale(1); opacity: 1; }
            50% { transform: scale(max(0.8, calc(var(--ripple-factor) / 100))); opacity: 0.42; }
            65% { opacity: 1; }
            70% { transform: scale(1.5); filter: var(--ripple-filter); }
            to { transform: scale(1); opacity: 1; }
        }

        .container.show-ripple {
            pointer-events: none;
        }

        .container.show-ripple .hexagon {
            cursor: default;
            animation: ripple 0.45s ease-in-out;
            animation-duration: max(0.45s, calc(0.45s * var(--ripple-factor) / 100));
            animation-delay: calc(var(--ripple-factor) * 8ms);
        }
    </style>
</head>
<body>
    <div id="container" class="container"></div>
    <div id="switch" class="switch"></div>

    <div id="configModal">
        <div class="modal-content">
            <h2>Edit Configuration</h2>
            <textarea id="configTextarea"><?php echo $config_json; ?></textarea>
            <button id="saveConfig">保存</button>
            <button id="closeModal">关闭</button>
        </div>
    </div>

    <script>
(() => {
    const container = document.getElementById("container");
    const iconData = <?php echo $config_json; ?>;

    function createHexagons() {
        container.innerHTML = '';
        const totalIcons = iconData.length;
        const columns = 9; // 设置总列数
        const middleColumn = Math.floor(columns / 2);

        for (let col = 0; col < columns; col++) {
            const columnDiv = document.createElement('div');
            columnDiv.className = 'column';
            columnDiv.style.setProperty('--column', col);

            // 计算每列应该有多少个图标
            let iconsInThisColumn;
            if (col <= middleColumn) {
                iconsInThisColumn = 5 + col;
            } else {
                iconsInThisColumn = 5 + (columns - 1 - col);
            }

            for (let row = 0; row < iconsInThisColumn; row++) {
                const index = (col * 5) + row; // 计算在 iconData 中的索引
                if (index >= totalIcons) break; // 如果超出 iconData 范围，停止创建

                const data = iconData[index];
                const hexagon = document.createElement('a');
                hexagon.className = 'hexagon';
                hexagon.style.setProperty('--index', row);
                hexagon.dataset.icon = data.icon;
                hexagon.href = data.url;
                hexagon.title = data.description;
                if (data.icon !== '⚙️') {
                    hexagon.target = '_blank';
                }
                columnDiv.appendChild(hexagon);
            }

            container.appendChild(columnDiv);
        }

        const hexagons = container.querySelectorAll(".hexagon");
        hexagons.forEach((hexagon) => {
            if (hexagon.dataset.icon === '⚙️') {
                hexagon.addEventListener("click", (e) => {
                    e.preventDefault();
                    document.getElementById('configModal').style.display = 'block';
                });
            } else {
                hexagon.addEventListener("click", (e) => {
                    e.preventDefault();
                    ripple(hexagon);
                    setTimeout(() => {
                        window.open(hexagon.href, '_blank');
                    }, 450);
                });
            }
        });
    }


        createHexagons();

        const ripple = (target) => {
            if (container.classList.contains("show-ripple")) return;
            
            const targetRect = target.getBoundingClientRect();
            const hexagons = container.querySelectorAll(".hexagon");
            const data = Array.from(hexagons)
                .map((element) => {
                    const rect = element.getBoundingClientRect();
                    const centerX = rect.x + rect.width / 2;
                    const centerY = rect.y + rect.height / 2;
                    const distance = Math.round(
                        Math.sqrt(
                            Math.pow(rect.x - targetRect.x, 2) +
                            Math.pow(rect.y - targetRect.y, 2)
                        )
                    );
                    return { element, rect, centerX, centerY, distance };
                })
                .sort((a, b) => a.distance - b.distance);

            const [max] = data.slice(-1);
            data.forEach((item) =>
                item.element.style.setProperty(
                    "--ripple-factor",
                    `${(item.distance * 100) / max.distance}`
                )
            );
            container.classList.add("show-ripple");
            
            const cleanUp = () => {
                requestAnimationFrame(() => {
                    container.classList.remove("show-ripple");
                    data.forEach((item) =>
                        item.element.style.removeProperty("--ripple-factor")
                    );
                    max.element.removeEventListener("animationend", cleanUp);
                });
            };
            max.element.addEventListener("animationend", cleanUp);
        };

        const switchButton = document.getElementById('switch');
        const toggleTheme = () => {
            switchButton.classList.toggle('checked');
            document.documentElement.classList.toggle('vision-ui');
        };
        switchButton.addEventListener('click', toggleTheme);

        // 设置初始状态
        switchButton.classList.add('checked');

        const configModal = document.getElementById('configModal');
        const configTextarea = document.getElementById('configTextarea');
        const saveConfigButton = document.getElementById('saveConfig');
        const closeModalButton = document.getElementById('closeModal');

        saveConfigButton.addEventListener('click', () => {
            const newConfig = JSON.parse(configTextarea.value);
            fetch('save.php', {
                method: 'POST',
                headers: {                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(newConfig),
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    iconData.splice(0, iconData.length, ...newConfig);
                    createHexagons();
                    configModal.style.display = 'none';
                } else {
                    alert('Failed to save configuration');
                }
            });
        });

        closeModalButton.addEventListener('click', () => {
            configModal.style.display = 'none';
        });

        window.onclick = (event) => {
            if (event.target == configModal) {
                configModal.style.display = 'none';
            }
        };

        // 初始化时触发一次涟漪效果
        setTimeout(() => {
            const firstHexagon = document.querySelector(".hexagon");
            if (firstHexagon) {
                ripple(firstHexagon);
            }
        }, 300);
    })();
    </script>
</body>
</html>